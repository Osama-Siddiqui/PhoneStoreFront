﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectWebForm
{
    public partial class ItemList : Form

    {
        DataTable mydt = new DataTable();
        SqlConnection myconn = new SqlConnection();
        SqlCommand mycommand = new SqlCommand();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        
        public ItemList()
        {
            InitializeComponent();
            myconn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Class.CST\\Downloads\\CST4708Project.mdf;Integrated Security=True;Connect Timeout=30";
            myconn.Open();
            mycommand.Parameters.Add("@phoneOs", SqlDbType.VarChar, 50, "ProductOS");
            //mycommand.Parameters.Add("@phoneScreen", SqlDbType.VarChar, 50, "ScreenSize");
            //mycommand.Parameters.Add("@phoneMem", SqlDbType.VarChar, 50, "MemorySize");
            //mycommand.Parameters.Add("@phoneRam", SqlDbType.VarChar, 50, "RamSize");
            //mycommand.Parameters.Add("@phoneCam", SqlDbType.VarChar, 50, "Camera");
            //mycommand.Parameters.Add("@phoneCost", SqlDbType.VarChar, 50, "ProductCost");
            //mycommand.Parameters.Add("@phoneName", SqlDbType.VarChar, 50, "ProductName");
        }

        private void ItemList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cST4708ProjectDataSet11.ProductsTable' table. You can move, or remove it, as needed.
            this.productsTableTableAdapter1.Fill(this.cST4708ProjectDataSet11.ProductsTable);
            // TODO: This line of code loads data into the 'cST4708ProjectDataSet.ProductsTable' table. You can move, or remove it, as needed.
            this.productsTableTableAdapter.Fill(this.cST4708ProjectDataSet.ProductsTable);

        }

   

        private void AndroidButton_Click(object sender, EventArgs e)
        {
            mydt.Clear();
            mycommand.CommandText = "Select * from ProductsTable where ProductOS=@phoneOS";
            //MessageBox.Show(listBox1.SelectedValue.ToString());
            mycommand.Parameters["@phoneOS"].Value = "Android";
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            //dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = mydt;
            //dataGridView1.DataSourceBinding(mydt);
        }

        private void iOSButton_Click(object sender, EventArgs e)
        {
            mydt.Clear();
            mycommand.CommandText = "Select * from ProductsTable where ProductOS=@phoneOS";
            //MessageBox.Show(listBox1.SelectedValue.ToString());
            mycommand.Parameters["@phoneOS"].Value = "iOS";
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            //dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = mydt;
        }

        private void WindowsButton_Click(object sender, EventArgs e)
        {
            mydt.Clear();
            mycommand.CommandText = "Select * from ProductsTable where ProductOS=@phoneOS";
            //MessageBox.Show(listBox1.SelectedValue.ToString());
            mycommand.Parameters["@phoneOS"].Value = "Windows";
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            //dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = mydt;
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            mydt.Clear();
            mycommand.CommandText = "Select * from ProductsTable";
            //MessageBox.Show(listBox1.SelectedValue.ToString());
            
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            //dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = mydt;
        }
    }
}
