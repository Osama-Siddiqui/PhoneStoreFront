﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectWebForm
{
    public partial class Welcome : Form
    {
        DataTable mydt = new DataTable();
        SqlConnection myconn = new SqlConnection();
        SqlCommand mycommand = new SqlCommand();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        
        public Welcome()
        {
            myconn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Class.CST\\Downloads\\CST4708Project.mdf;Integrated Security=True;Connect Timeout=30";
            myconn.Open();
            //Making paramaters global so I dont throw errors if checkPassword() is done multiple times
            //As that would atempt to recreate a var that already exists in memory 
            mycommand.Parameters.Add("@username", SqlDbType.VarChar, 50, "Username");
             mycommand.Parameters.Add("@password", SqlDbType.VarChar, 50, "Password");
             
         
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            //if statement checking account Username/Password
           if(checkPassword() == true)
            {
                //Redirect to Purchse forms
                //Message Box to check if it works/ remove later
                MessageBox.Show("Sucess");
                
                this.Hide();
                //Refirect to ItemList form
                itemListRedirect();
            }else if (checkPassword()== false)
            {
                //Trhow message box error telling username/password is false
                MessageBox.Show("Error Invalid Username/Password");
            }
        }
        public Boolean checkPassword()
        {
            //Boolean checks if username/password match a username/password within the database.
            mydt.Clear();

            mycommand.CommandText = "Select Username from UserInfoTable where Username = @username AND Password = @password";
           // mycommand.Parameters.Add("@username", SqlDbType.VarChar, 50, "Username");
            mycommand.Parameters["@username"].Value = UsernameTextBox.Text;
           // mycommand.Parameters.Add("@password", SqlDbType.VarChar, 50, "Password");
            mycommand.Parameters["@password"].Value = PasswordTextBox.Text;
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            if (mydt.Rows.Count > 0)
            {
                //if table contains a row, a match has been found and return true
                return true;
            }else
            {//No match has been found and return false
                return false;
            }
        }

        private void CreateAccountLabel_Click(object sender, EventArgs e)
        {
           
            createAccountRedirect();
        }
        public void createAccountRedirect()
        {
            //this.Hide hides current from, must make sure to add a button to return to previous form
            this.Hide();
            //Made into its own method in main since I truley don't know how often its going to be used
            //Might not even be worth making into a method idk
            var createAccount = new CreateAccountForm();    
            createAccount.Show();
        }
        public void signInRedirect()
        {
            //this.Hide hides current from, must make sure to add a button to return to previous form
            this.Hide();
            //Made into its own method in main since I truley don't know how often its going to be used
            //Might not even be worth making into a method idk
            var signIn = new Welcome();
            signIn.Show();
            
        }
        public void itemListRedirect()
        {
            //this.Hide hides current from, must make sure to add a button to return to previous form
            this.Hide();
            //Made into its own method in main since I truley don't know how often its going to be used
            //Might not even be worth making into a method idk
            var itemList = new ItemList();
            itemList.Show();

        }
        

        private void Welcome_Load(object sender, EventArgs e)
        {

        }
    }
    
}
