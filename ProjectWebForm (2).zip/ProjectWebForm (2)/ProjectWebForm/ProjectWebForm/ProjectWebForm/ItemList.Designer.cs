﻿namespace ProjectWebForm
{
    partial class ItemList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.productsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cST4708ProjectDataSet = new ProjectWebForm.CST4708ProjectDataSet();
            this.productsTableTableAdapter = new ProjectWebForm.CST4708ProjectDataSetTableAdapters.ProductsTableTableAdapter();
            this.csT4708ProjectDataSet1 = new ProjectWebForm.CST4708ProjectDataSet();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productOSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.screenSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memorySizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ramSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cameraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsTableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cST4708ProjectDataSet11 = new ProjectWebForm.CST4708ProjectDataSet1();
            this.productsTableTableAdapter1 = new ProjectWebForm.CST4708ProjectDataSet1TableAdapters.ProductsTableTableAdapter();
            this.AndroidButton = new System.Windows.Forms.Button();
            this.iOSButton = new System.Windows.Forms.Button();
            this.WindowsButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.productsTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cST4708ProjectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.csT4708ProjectDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsTableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cST4708ProjectDataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(332, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 85);
            this.label1.TabIndex = 0;
            this.label1.Text = "Categories";
            // 
            // productsTableBindingSource
            // 
            this.productsTableBindingSource.DataMember = "ProductsTable";
            this.productsTableBindingSource.DataSource = this.cST4708ProjectDataSet;
            // 
            // cST4708ProjectDataSet
            // 
            this.cST4708ProjectDataSet.DataSetName = "CST4708ProjectDataSet";
            this.cST4708ProjectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsTableTableAdapter
            // 
            this.productsTableTableAdapter.ClearBeforeFill = true;
            // 
            // csT4708ProjectDataSet1
            // 
            this.csT4708ProjectDataSet1.DataSetName = "CST4708ProjectDataSet";
            this.csT4708ProjectDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productOSDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.screenSizeDataGridViewTextBoxColumn,
            this.memorySizeDataGridViewTextBoxColumn,
            this.ramSizeDataGridViewTextBoxColumn,
            this.cameraDataGridViewTextBoxColumn,
            this.productCostDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productsTableBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(4, 112);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(418, 292);
            this.dataGridView1.TabIndex = 1;
            // 
            // productOSDataGridViewTextBoxColumn
            // 
            this.productOSDataGridViewTextBoxColumn.DataPropertyName = "ProductOS";
            this.productOSDataGridViewTextBoxColumn.HeaderText = "ProductOS";
            this.productOSDataGridViewTextBoxColumn.Name = "productOSDataGridViewTextBoxColumn";
            this.productOSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "ProductName";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "ProductName";
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            this.productNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // screenSizeDataGridViewTextBoxColumn
            // 
            this.screenSizeDataGridViewTextBoxColumn.DataPropertyName = "ScreenSize";
            this.screenSizeDataGridViewTextBoxColumn.HeaderText = "ScreenSize";
            this.screenSizeDataGridViewTextBoxColumn.Name = "screenSizeDataGridViewTextBoxColumn";
            this.screenSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // memorySizeDataGridViewTextBoxColumn
            // 
            this.memorySizeDataGridViewTextBoxColumn.DataPropertyName = "MemorySize";
            this.memorySizeDataGridViewTextBoxColumn.HeaderText = "MemorySize";
            this.memorySizeDataGridViewTextBoxColumn.Name = "memorySizeDataGridViewTextBoxColumn";
            this.memorySizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ramSizeDataGridViewTextBoxColumn
            // 
            this.ramSizeDataGridViewTextBoxColumn.DataPropertyName = "RamSize";
            this.ramSizeDataGridViewTextBoxColumn.HeaderText = "RamSize";
            this.ramSizeDataGridViewTextBoxColumn.Name = "ramSizeDataGridViewTextBoxColumn";
            this.ramSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cameraDataGridViewTextBoxColumn
            // 
            this.cameraDataGridViewTextBoxColumn.DataPropertyName = "Camera";
            this.cameraDataGridViewTextBoxColumn.HeaderText = "Camera";
            this.cameraDataGridViewTextBoxColumn.Name = "cameraDataGridViewTextBoxColumn";
            this.cameraDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productCostDataGridViewTextBoxColumn
            // 
            this.productCostDataGridViewTextBoxColumn.DataPropertyName = "ProductCost";
            this.productCostDataGridViewTextBoxColumn.HeaderText = "ProductCost";
            this.productCostDataGridViewTextBoxColumn.Name = "productCostDataGridViewTextBoxColumn";
            this.productCostDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productsTableBindingSource1
            // 
            this.productsTableBindingSource1.DataMember = "ProductsTable";
            this.productsTableBindingSource1.DataSource = this.cST4708ProjectDataSet11;
            // 
            // cST4708ProjectDataSet11
            // 
            this.cST4708ProjectDataSet11.DataSetName = "CST4708ProjectDataSet1";
            this.cST4708ProjectDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsTableTableAdapter1
            // 
            this.productsTableTableAdapter1.ClearBeforeFill = true;
            // 
            // AndroidButton
            // 
            this.AndroidButton.Location = new System.Drawing.Point(454, 96);
            this.AndroidButton.Name = "AndroidButton";
            this.AndroidButton.Size = new System.Drawing.Size(75, 23);
            this.AndroidButton.TabIndex = 3;
            this.AndroidButton.Text = "Android";
            this.AndroidButton.UseVisualStyleBackColor = true;
            this.AndroidButton.Click += new System.EventHandler(this.AndroidButton_Click);
            // 
            // iOSButton
            // 
            this.iOSButton.Location = new System.Drawing.Point(539, 96);
            this.iOSButton.Name = "iOSButton";
            this.iOSButton.Size = new System.Drawing.Size(75, 23);
            this.iOSButton.TabIndex = 4;
            this.iOSButton.Text = "iOS";
            this.iOSButton.UseVisualStyleBackColor = true;
            this.iOSButton.Click += new System.EventHandler(this.iOSButton_Click);
            // 
            // WindowsButton
            // 
            this.WindowsButton.Location = new System.Drawing.Point(454, 136);
            this.WindowsButton.Name = "WindowsButton";
            this.WindowsButton.Size = new System.Drawing.Size(75, 23);
            this.WindowsButton.TabIndex = 5;
            this.WindowsButton.Text = "Windows";
            this.WindowsButton.UseVisualStyleBackColor = true;
            this.WindowsButton.Click += new System.EventHandler(this.WindowsButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(539, 136);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(75, 23);
            this.ResetButton.TabIndex = 6;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // ItemList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjectWebForm.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.WindowsButton);
            this.Controls.Add(this.iOSButton);
            this.Controls.Add(this.AndroidButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "ItemList";
            this.Text = "Items";
            this.Load += new System.EventHandler(this.ItemList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.productsTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cST4708ProjectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.csT4708ProjectDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsTableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cST4708ProjectDataSet11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private CST4708ProjectDataSet cST4708ProjectDataSet;
        private System.Windows.Forms.BindingSource productsTableBindingSource;
        private CST4708ProjectDataSetTableAdapters.ProductsTableTableAdapter productsTableTableAdapter;
        private CST4708ProjectDataSet csT4708ProjectDataSet1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CST4708ProjectDataSet1 cST4708ProjectDataSet11;
        private System.Windows.Forms.BindingSource productsTableBindingSource1;
        private CST4708ProjectDataSet1TableAdapters.ProductsTableTableAdapter productsTableTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productOSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn screenSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn memorySizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ramSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cameraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button AndroidButton;
        private System.Windows.Forms.Button iOSButton;
        private System.Windows.Forms.Button WindowsButton;
        private System.Windows.Forms.Button ResetButton;
    }
}