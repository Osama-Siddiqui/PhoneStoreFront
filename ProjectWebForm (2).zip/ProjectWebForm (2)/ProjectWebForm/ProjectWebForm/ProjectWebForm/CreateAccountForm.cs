﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectWebForm
{
    public partial class CreateAccountForm : Form
    {
        DataTable mydt = new DataTable();
        SqlConnection myconn = new SqlConnection();
        SqlCommand mycommand = new SqlCommand();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        //Declaring sign as new signinform to use methods within Signinform
        Welcome sign  = new Welcome();
        public CreateAccountForm()
        {
            InitializeComponent();
            myconn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Class.CST\\Downloads\\CST4708Project.mdf;Integrated Security=True;Connect Timeout=30";
            myconn.Open();
            mycommand.Parameters.Add("@fName", SqlDbType.VarChar, 50, "FirstName");
            mycommand.Parameters.Add("@lName", SqlDbType.VarChar, 50, "LastName");
            mycommand.Parameters.Add("@phoneNumber", SqlDbType.VarChar, 50, "PhoneNumber");
            mycommand.Parameters.Add("@username", SqlDbType.VarChar, 50, "Username");
            mycommand.Parameters.Add("@password", SqlDbType.VarChar, 50, "Password");
            mycommand.Parameters.Add("@userAddress", SqlDbType.VarChar, 50, "UserAddress");
            mycommand.Parameters.Add("@ccNumber", SqlDbType.VarChar, 50, "CCNumber");
        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void CreateAccountButton_Click(object sender, EventArgs e)
        {
            if(usernameExist()== false)
            {
                //Username not in use, adding user
                addnewUser();
                MessageBox.Show("User Created!, Now redirecting to log in page");
                //Use redirect method within Sign in Form
                sign.signInRedirect();
                this.Hide();

            }

        }
        public Boolean usernameExist()
        {
            //Clear and use table to check if username is in use
            //Ghetto atempt to prevent dupes
            mydt.Clear();
            mycommand.CommandText = "Select Username from UserInfoTable where Username=@username";
            //Now you may be wondering, Why fill all these other paramaters if its not used in the select statement
            //Well since I declared them on start I need to use them else i'll have a error of paramaters expectng to get a value but not recieving any.
            mycommand.Parameters["@fName"].Value = FirstNameTextBox.Text;
            mycommand.Parameters["@lName"].Value = LastNameTextBox.Text;
            mycommand.Parameters["@phoneNumber"].Value = PhoneTextBox.Text;
            mycommand.Parameters["@username"].Value = UsernameTextBox.Text;
            mycommand.Parameters["@password"].Value = PasswordTextBox.Text;
            mycommand.Parameters["@userAddress"].Value = AddressTextBox.Text;
            mycommand.Parameters["@ccNumber"].Value = CreditCardTextBox.Text;
            mycommand.Connection = myconn;
            myadapter.SelectCommand = mycommand;
            myadapter.Fill(mydt);
            if (mydt.Rows.Count > 0)
            {
                //If username is found throw message box telling user to make a new username and return true to prevent insert
                MessageBox.Show("Username is taken, please select a new username");
                return true;
            }
            else
            {
                //Username not found, assuming its not in use, return false
                //At one point these two were true-false but sounded kinda dumb to have a method called usernameExsit return false after finding out the username existed
                return false;
            }
        }
        public void addnewUser()
        {
            mycommand.CommandText = "INSERT INTO UserInfoTable (FirstName,LastName,PhoneNumber,Username,Password,UserAddress,CCNumber) VALUES (@fName,@lName,@phoneNumber,@username,@password,@userAddress,@ccNumber)";
            mycommand.Parameters["@fName"].Value = FirstNameTextBox.Text;
            mycommand.Parameters["@lName"].Value = LastNameTextBox.Text;
            mycommand.Parameters["@phoneNumber"].Value = PhoneTextBox.Text;
            mycommand.Parameters["@username"].Value = UsernameTextBox.Text;
            mycommand.Parameters["@password"].Value = PasswordTextBox.Text;
            mycommand.Parameters["@userAddress"].Value = AddressTextBox.Text;
            mycommand.Parameters["@ccNumber"].Value = CreditCardTextBox.Text;
            mycommand.Connection = myconn;
            myadapter.InsertCommand = mycommand;
            mycommand.ExecuteNonQuery();
        }
       
    }
}
